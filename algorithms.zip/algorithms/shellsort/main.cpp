#include <bits/stdc++.h>
using namespace std;
ofstream fout("arranged.out");
int n, List[10005];
int shellSort(int arr[], int n) {
    for (int gap = n/2; gap > 0; gap /= 2) {
        for (int i = gap; i < n; i += 1) {
            int temp = arr[i];
            int j;
            for (j = i; j >= gap && arr[j - gap] > temp; j -= gap)
                arr[j] = arr[j - gap];

            arr[j] = temp;
        }
    }
    return 0;
}
int main()
{
    clock_t start, end;
    cout<<"Enter array lenght:\n";
    cin>>n;
    for(int i=0;i<n;i++)
        cin>>List[i];
    start = clock();
    shellSort(List, n);
    for(int i=1;i<n;i++)
        fout<<List[i]<<" ";
    end = clock();
    double time_taken = double(end - start) / double(CLOCKS_PER_SEC);
    cout << "Time taken by program is : " << fixed << time_taken << setprecision(9);
    return 0;
}

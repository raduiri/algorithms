#include <bits/stdc++.h>
#include <stdio.h>
#include <processthreadsapi.h>
using namespace std;
ofstream fout("arranged.out");
int n, List[10005];
void swap(int *xp, int *yp) {
    int temp = *xp;
    *xp = *yp;
    *yp = temp;
}
void bubbleSort(int arr[], int n) {
    int i, j;
    for (i = 0; i < n-1; i++)
        for (j = 0; j < n-i-1; j++)
            if (arr[j] > arr[j+1])
                swap(&arr[j], &arr[j+1]);
}
int main()
{
    clock_t start, end;
    cout<<"Enter array lenght:\n";
    cin>>n;
    for(int i=0;i<n;i++)
        cin>>List[i];
    start = clock();
    bubbleSort(List, n);
    for(int i=1;i<n;i++)
        fout<<List[i]<<" ";
    end = clock();
    double time_taken = double(end - start) / double(CLOCKS_PER_SEC);
    cout << "Time taken by program is : " << fixed << time_taken << setprecision(9);
    return 0;
}

#include <bits/stdc++.h>
using namespace std;
ofstream fout("arranged.out");
int n, List[10005];
void swap(int* a, int* b)
{
    int t = *a;
    *a = *b;
    *b = t;
}
int partition (int arr[], int low, int high)
{
    int pivot = arr[high];
    int i = (low - 1);

    for (int j = low; j <= high- 1; j++)
    {
        if (arr[j] <= pivot)
        {
            i++;
            swap(&arr[i], &arr[j]);
        }
    }
    swap(&arr[i + 1], &arr[high]);
    return (i + 1);
}
void quickSort(int arr[], int low, int high)
{
    if (low < high)
    {
        int pivot = partition(arr, low, high);

        quickSort(arr, low, pivot - 1);
        quickSort(arr, pivot + 1, high);
    }
}
int main()
{
    clock_t start, end;
    cout<<"Enter array lenght:\n";
    cin>>n;
    for(int i=0;i<n;i++)
        cin>>List[i];
    start = clock();
    quickSort(List, 0, n-1);
    for(int i=1;i<n;i++)
        fout<<List[i]<<" ";
    end = clock();
    double time_taken = double(end - start) / double(CLOCKS_PER_SEC);
    cout << "Time taken by program is : " << fixed << time_taken << setprecision(9);
    return 0;
}

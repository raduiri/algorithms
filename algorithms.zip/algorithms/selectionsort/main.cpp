#include <bits/stdc++.h>
using namespace std;
ofstream fout("arranged.out");
int n, List[10005];
void swap(int *xp, int *yp) {
    int temp = *xp;
    *xp = *yp;
    *yp = temp;
}
void selectionSort(int arr[], int n) {
    int i, j, min_idx;

    for (i = 0; i < n-1; i++) {
        min_idx = i;
        for (j = i+1; j < n; j++)
            if (arr[j] < arr[min_idx])
                min_idx = j;

        swap(&arr[min_idx], &arr[i]);
    }
}
int main()
{
    clock_t start, end;
    cout<<"Enter array lenght:\n";
    cin>>n;
    for(int i=0;i<n;i++)
        cin>>List[i];
    start = clock();
    selectionSort(List, n);
    for(int i=1;i<n;i++)
        fout<<List[i]<<" ";
    end = clock();
    double time_taken = double(end - start) / double(CLOCKS_PER_SEC);
    cout << "Time taken by program is : " << fixed << time_taken << setprecision(9);
    return 0;
}
